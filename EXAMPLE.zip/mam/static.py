about = '''
Authors : Jerome Francois, Lautaro Dolberg (first.second@uni.lu)
Date : 16/05/2012
All rights reserved
GPL version 2.0 to be found at: http://www.gnu.org/licenses/gpl-2.0.txt
2012 University of Luxembourg - Interdisciplinary Centre for Security Reliability and Trust (SnT)
'''